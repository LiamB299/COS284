#include <stdlib.h>
#include <unistd.h>

extern float color_distance(unsigned a, unsigned b);

void iseq(float a, float b) {
	float c = a - b;
	if (c < 0.0) {
		c *= -1;
	}
	char bf[2];
	bf[1] = '\n';
	if (c < 0.0001) {
		bf[0] = '1';
	} else {
		bf[0] = '0';
	}
	write(1, bf, 2);
}

int main(int argc, char *argv[]) {
	
	iseq(color_distance(0xD6FF21, 0x6178BB), 406.500610); // should output 1
	
	return 0;
}
