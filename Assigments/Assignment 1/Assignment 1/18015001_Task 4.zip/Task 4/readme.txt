The folder "programs" contains the original scripts for each language and means for writing each to .exe

The folder "data" contains .exes for each langauge.
	Bash.txt holds the bash commands used to collect the timing data.
	test.py is then run to compute the statistics for each language to output_stats.txt
	The data is then graphed in LibreOffice
	
Report is written in Latex- Overleaf

