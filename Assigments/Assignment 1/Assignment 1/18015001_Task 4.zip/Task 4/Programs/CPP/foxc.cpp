#include <iostream>

int main() {
    std::cout<<"The quick brown fox jumps over the lazy dog.";
    return 0;
}
